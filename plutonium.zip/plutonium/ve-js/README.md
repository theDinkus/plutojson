This directory should contain copies of 5etools':
 - `utils.js`
 - `utils-ui.js`
 - `render.js`
 - `scalecreature.js`
 - `list2.js`
 - `filter.js`
 - `filter-spells.js`
 - `parser.js`
